﻿namespace FrameworkLibrary
{
    public enum RoomMode
    {
        Public,
        Private
    }
}
