﻿namespace FrameworkLibrary
{
    public enum AuthType
    {
        Forms,
        Windows
    }
}