﻿namespace FrameworkLibrary
{
    public enum ContextType
    {
        Session,
        Application,
        RequestContext,
        Cache,
        ViewState
    }
}