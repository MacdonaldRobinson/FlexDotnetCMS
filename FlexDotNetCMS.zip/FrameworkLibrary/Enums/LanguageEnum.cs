﻿namespace FrameworkLibrary
{
    public enum LanguageEnum
    {
        English,
        French
    }
}