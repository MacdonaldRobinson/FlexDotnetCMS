﻿namespace FrameworkLibrary
{
    public enum MediaTypeEnum
    {
        Page,
        RootPage,
        UrlRedirectRule,
        UrlRedirectRuleList,
        Website,
        Include
    }
}