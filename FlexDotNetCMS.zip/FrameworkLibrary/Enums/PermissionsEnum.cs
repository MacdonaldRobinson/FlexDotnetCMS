﻿namespace FrameworkLibrary
{
    public enum PermissionsEnum
    {
        AccessCMS,
        AccessAdvanceOptions,
        FrontEndEditor,
        Create,
        Save,
        Delete,
        Publish        
    }
}