﻿namespace FrameworkLibrary
{
    public enum RenderVersion
    {
        Mobile,
        HTML
    }
}