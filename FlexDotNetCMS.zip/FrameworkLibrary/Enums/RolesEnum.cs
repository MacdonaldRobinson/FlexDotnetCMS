﻿namespace FrameworkLibrary
{
    public enum RoleEnum
    {
        Developer,
        Administrator
    }
}