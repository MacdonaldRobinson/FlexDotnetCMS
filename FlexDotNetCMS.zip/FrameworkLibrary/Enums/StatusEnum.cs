﻿namespace FrameworkLibrary
{
    public enum StatusEnum
    {
        Approved,
        Pending,
        Rejected
    }
}