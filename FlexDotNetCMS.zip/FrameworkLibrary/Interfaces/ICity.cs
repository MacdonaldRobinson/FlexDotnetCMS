﻿namespace FrameworkLibrary
{
    public interface ICity
    {
        string Title { get; set; }

        string Province { get; set; }

        string Country { get; set; }
    }
}