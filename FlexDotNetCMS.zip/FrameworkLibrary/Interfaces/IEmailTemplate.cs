﻿namespace FrameworkLibrary
{
    public interface IEmailTemplate
    {
        void SetParams(object[] parameters);
    }
}