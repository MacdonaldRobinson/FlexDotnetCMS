﻿namespace FrameworkLibrary
{
    public interface IParamControl
    {
        void SetParams(object[] parameters);
    }
}