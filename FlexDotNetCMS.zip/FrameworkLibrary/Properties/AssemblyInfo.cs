﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Mac's RAD Framework / CMS")]
[assembly: AssemblyDescription("Mac's RAD Framework / CMS built by Macdonald Robinson - http://www.linkedin.com/in/macdonaldrobinson")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("http://www.linkedin.com/in/macdonaldrobinson")]
[assembly: AssemblyProduct("Mac's RAD Framework / CMS")]
[assembly: AssemblyCopyright("Macdonald Robinson - http://www.linkedin.com/in/macdonaldrobinson")]
[assembly: AssemblyTrademark("Macdonald Robinson - http://www.linkedin.com/in/macdonaldrobinson")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(true)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("da59cc6d-b437-4756-aeb9-f4c1ed6d9258")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]