﻿using FrameworkLibrary;
using System;

namespace WebApplication.Admin
{
    public partial class FileExplorerDialog : System.Web.UI.Page
    {
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
        }
    }
}