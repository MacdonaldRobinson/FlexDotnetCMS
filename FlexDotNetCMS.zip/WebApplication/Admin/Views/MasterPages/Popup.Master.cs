﻿using System;

namespace WebApplication.Admin.Views.MasterPages
{
    public partial class Popup : BaseMasterPage
    {
    }
}