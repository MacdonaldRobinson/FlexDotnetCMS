﻿using FrameworkLibrary;
using System;

namespace WebApplication.Admin.MediaArticle
{
    public partial class Default : AdminBasePage
    {
    }
}