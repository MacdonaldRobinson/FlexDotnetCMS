﻿using System;

namespace WebApplication.Controls.Facebook
{
    public partial class Comments : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}