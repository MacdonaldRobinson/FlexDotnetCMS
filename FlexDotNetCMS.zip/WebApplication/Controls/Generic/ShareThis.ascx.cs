﻿using System;

namespace WebApplication.Controls
{
    public partial class ShareThis : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}