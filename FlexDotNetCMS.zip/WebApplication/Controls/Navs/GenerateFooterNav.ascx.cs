﻿using System;

namespace WebApplication.Controls.Navs
{
    public partial class GenerateFooterNav : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}