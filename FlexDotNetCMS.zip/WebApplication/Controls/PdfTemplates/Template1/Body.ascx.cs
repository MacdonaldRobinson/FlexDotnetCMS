﻿namespace WebApplication.Controls.PdfTemplates.Template1
{
    public partial class Body : System.Web.UI.UserControl
    {
        public Body()
        {
        }

        public Body(object obj)
        {
        }
    }
}