﻿namespace WebApplication.Controls.PdfTemplates.Template1
{
    public partial class Footer : System.Web.UI.UserControl
    {
        public Footer()
        {
        }

        public Footer(object obj)
        {
        }
    }
}