﻿using System;

namespace WebApplication.Controls
{
    public partial class TakeActionTab : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}