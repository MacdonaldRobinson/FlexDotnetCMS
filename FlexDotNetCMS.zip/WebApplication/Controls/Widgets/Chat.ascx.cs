﻿using FrameworkLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication.Controls.Widgets
{
    public partial class Chat : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (ChatRoomMode == RoomMode.Private)
            {

            }
        }

        public RoomMode ChatRoomMode { get; set; } = RoomMode.Public;
    }
}